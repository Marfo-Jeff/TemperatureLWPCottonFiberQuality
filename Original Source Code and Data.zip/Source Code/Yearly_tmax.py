import arcpy
import os

# --- CONFIGURATION ---
# Just update these four paths
tmax_dir = r"D:\PRISM_800m_TIFF\Tmax"
output_dir = r"D:\PRISM_800m_TIFF\Tmax_Yearly_Averages" 
final_output = r"D:\PRISM_800m_TIFF\MS_Tmax_2005_2025_Mean.tif"
county_shp = r"\MS_CountyBoundaries_2015.shp"

if not os.path.exists(output_dir):
    os.makedirs(output_dir)

try:
    print("Checking out Spatial Analyst...")
    arcpy.CheckOutExtension("Spatial")
    
    # Environment Settings
    arcpy.env.overwriteOutput = True
    arcpy.env.mask = county_shp  # Clips to MS boundary
    arcpy.env.extent = county_shp
    
    # 1. Group files by year
    all_tifs = [f for f in os.listdir(tmax_dir) if f.lower().endswith('.tif')]
    years = {}
    
    for tif in all_tifs:
        # Extract year from filename
        year = tif.split('_')[-1][:4] 
        if year not in years:
            years[year] = []
        years[year].append(os.path.join(tmax_dir, tif))

    yearly_avg_files = []
    total_years = len(years)

    # 2. Average each year individually (Safe for laptop)
    print(f"Found {total_years} years to process.")
    
    for i, (year, files) in enumerate(sorted(years.items()), 1):
        print(f"[{i}/{total_years}] Processing Year: {year} ({len(files)} files)...")
        
        # Calculate mean for the year
        # This pixel-by-pixel math is done inside the MS mask only
        year_mean = arcpy.sa.CellStatistics(files, "MEAN", "DATA")
        
        # Save intermediate yearly file
        out_year_path = os.path.join(output_dir, f"Avg_Tmax_{year}.tif")
        year_mean.save(out_year_path)
        yearly_avg_files.append(out_year_path)

    # 3. Calculate the Grand Mean from the yearly averages
    print("Calculating final multi-year grand average for Tmax...")
    grand_mean = arcpy.sa.CellStatistics(yearly_avg_files, "MEAN", "DATA")
    grand_mean.save(final_output)

    print("-" * 30)
    print(f"SUCCESS!")
    print(f"Yearly files are in: {output_dir}")
    print(f"Final master Tmax raster: {final_output}")
    print("-" * 30)

finally:
    print("Releasing Spatial Analyst License.")
    arcpy.CheckInExtension("Spatial")