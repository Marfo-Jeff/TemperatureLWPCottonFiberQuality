import arcpy
import os

# --- CONFIGURATION ---
tmin_final = r"G:\PRISM_800m_TIFF\MS_Tmin_2005_2025_Mean.tif"
tmax_final = r"G:\PRISM_800m_TIFF\MS_Tmax_2005_2025_Mean.tif"
tmean_output = r"G:\PRISM_800m_TIFF\MS_Tmean_2005_2025_GrandAverage.tif"

try:
    print("Checking out Spatial Analyst...")
    arcpy.CheckOutExtension("Spatial")
    
    arcpy.env.overwriteOutput = True

    print("Calculating the average of Tmin and Tmax...")
    
    # Create Raster objects
    raster_min = arcpy.Raster(tmin_final)
    raster_max = arcpy.Raster(tmax_final)
    
    # Map Algebra: (Tmin + Tmax) / 2
    # This is done pixel-by-pixel
    tmean_raster = (raster_min + raster_max) / 2.0
    
    # Save the result
    print("Saving the Tmean raster...")
    tmean_raster.save(tmean_output)
    
    print(f"Success! The overall average temperature raster is saved at: {tmean_output}")

finally:
    print("Releasing Spatial Analyst License.")
    arcpy.CheckInExtension("Spatial")