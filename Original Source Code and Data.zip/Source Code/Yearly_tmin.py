import arcpy
import os

# --- CONFIGURATION ---
tmin_dir = r"D:\PRISM_800m_TIFF\Tmin"
output_dir = r"D:\PRISM_800m_TIFF\Tmin_Yearly_Averages" # Intermediate folder
final_output = r"D:\PRISM_800m_TIFF\MS_Tmin_2005_2025_Mean.tif"
county_shp = r"\MS_CountyBoundaries_2015.shp"

if not os.path.exists(output_dir):
    os.makedirs(output_dir)

try:
    print("Checking out Spatial Analyst...")
    arcpy.CheckOutExtension("Spatial")
    
    # Environment Settings
    arcpy.env.overwriteOutput = True
    arcpy.env.mask = county_shp  # Clips to MS boundary
    arcpy.env.extent = county_shp
    
    # 1. Group files by year
    all_tifs = [f for f in os.listdir(tmin_dir) if f.lower().endswith('.tif')]
    years = {}
    
    for tif in all_tifs:
        # Extract year: prism_tmin_us_30s_20040101.tif -> 2004
        year = tif.split('_')[-1][:4] 
        if year not in years:
            years[year] = []
        years[year].append(os.path.join(tmin_dir, tif))

    yearly_avg_files = []

    # 2. Average each year individually
    for year, files in sorted(years.items()):
        print(f"Processing Year: {year} ({len(files)} files)...")
        
        # Calculate mean for the year
        year_mean = arcpy.sa.CellStatistics(files, "MEAN", "DATA")
        
        # Save intermediate yearly file
        out_year_path = os.path.join(output_dir, f"Avg_{year}.tif")
        year_mean.save(out_year_path)
        yearly_avg_files.append(out_year_path)

    # 3. Calculate the Grand Mean from the yearly averages
    print("Calculating final 20-year grand average...")
    grand_mean = arcpy.sa.CellStatistics(yearly_avg_files, "MEAN", "DATA")
    grand_mean.save(final_output)

    print(f"Success! Master average saved to: {final_output}")

finally:
    print("Releasing Spatial Analyst License.")
    arcpy.CheckInExtension("Spatial")