
import os
import requests
import time
import zipfile
import io
from datetime import date, timedelta

# --- SETTINGS ---
start_date = date(2004, 1, 1)
end_date = date(2004, 8, 31) # Testing with 10 days first august 2004
variable = "tmax" ## Chnage to tmin
output_folder = r"D:/PRISM_800m_TIFF/Tmax" 


if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# --- DOWNLOAD LOOP ---
current_date = start_date
headers = {'User-Agent': 'Mozilla/5.0'}

while current_date <= end_date:
    date_str = current_date.strftime("%Y%m%d")
    # Note: No ?o=nc here. This gets the default ZIP package containing the TIFF/BIL
    url = f"https://services.nacse.org/prism/data/get/us/800m/{variable}/{date_str}"
    
    print(f"Processing {date_str}...")
    
    try:
        r = requests.get(url, headers=headers, timeout=30)
        
        if r.status_code == 200:
            # PRISM sends a ZIP file. We open it in memory.
            with zipfile.ZipFile(io.BytesIO(r.content)) as z:
                # Find the file inside the zip that ends with .tif
                tiff_file = [f for f in z.namelist() if f.endswith('.tif')]
                
                if tiff_file:
                    # Extract only the .tif file to your folder
                    z.extract(tiff_file[0], output_folder)
                    print(f"  Successfully extracted: {tiff_file[0]}")
                else:
                    print(f"  No TIFF found in ZIP for {date_str}")
        else:
            print(f"  Failed! Status code: {r.status_code}")

    except Exception as e:
        print(f"  Error on {date_str}: {e}")
    
    time.sleep(2) # Stay polite to the server
    current_date += timedelta(days=1)

print("\nAll done! Check your folder for .tif files.")
