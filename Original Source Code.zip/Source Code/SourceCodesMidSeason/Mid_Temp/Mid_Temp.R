library(readxl)
library(readr)
library(ggplot2)
library(dplyr)
library(RColorBrewer)
library(plotly)
library(lubridate)
library(ggpubr)
library(openxlsx)
library(grid)
library(tidyr)
library(tidyverse)
library(scales)
library(stringr) 
library(reshape2)
library(ggtext)
library("maps")
library(tigris)
library(sf)
library(openxlsx)

# LATEST PLANTING DATE----

process_file <- function(file_path) {
  # Read the CSV file
  data <- read_csv(file_path, show_col_types = FALSE)
  print(names(data))
  
  # Extract latitude and longitude from the first row
  latitude <- data$latitude[1]
  longitude <- data$longitude[1]
  
  # Reverse the data for backward accumulation
  data <- data[nrow(data):1, ]
  
  # Initialize variables
  accumulated_gdd <- 0
  latest_planting_day <- NA
  
  # Loop through each row backwards to calculate GDD and accumulate
  for (i in 1:nrow(data)) {
    avg_temp <- (data$average_tmax[i] + data$average_tmin[i]) / 2
    
    daily_gdd <- max(((9/5) * avg_temp + 32) - 60, 0)
    accumulated_gdd <- accumulated_gdd + daily_gdd
    
    if (accumulated_gdd >= 2400) {
      latest_planting_day <- data$yday[i]
      break
    }
  }
  
  return(list(
    file = file_path,
    latitude = latitude,
    longitude = longitude,
    latest_planting_day = latest_planting_day,
    total_gdd = accumulated_gdd
  ))
}



# Assuming all your files are in a directory "data_files"
files <- list.files(path = "C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/temp_cwsi_temp_merged", full.names = TRUE)

# Process each file
results <- lapply(files, process_file)

# Convert to a dataframe for easier viewing/manipulation
results_df <- do.call(rbind, results)
results_df<-as.data.frame(results_df)

# Check and handle NA values in the dataframe
results_df[is.na(results_df)] <- "NA"  # Replace NA with "NA" or another placeholder


#write.xlsx(results_df, file="C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Early_results/latest_early.xlsx")

#FIRST PLATNING DATE----
process_file_earliest <- function(file_path) {
  
  # Read the CSV file
  data <- read_csv(file_path, show_col_types = FALSE)
  print(names(data))
  
  
  # Extract latitude and longitude from the first row
  latitude <- data$latitude[1]
  longitude <- data$longitude[1]
  
  # Initialize variables
  consecutive_days_above_15 <- 0
  earliest_planting_day <- NA
  
  # Loop through each row to check average temperature
  for (i in 1:nrow(data)) {
    avg_temp <- (data$average_tmax[i] + data$average_tmin[i]) / 2
    
    # Updated: Include soil moisture condition for planting window
    if (avg_temp >= 15) {
      consecutive_days_above_15 <- consecutive_days_above_15 + 1
      if (consecutive_days_above_15 >= 7) {
        earliest_planting_day <- data$yday[i]
        break
      }
    } else {
      consecutive_days_above_15 <- 0  # Reset count if temperature drops below 15
    }
  }
  
  return(list(file = file_path, latitude = latitude, longitude = longitude, earliest_planting_day = earliest_planting_day))
}

# Process each file for earliest planting date
results_earliest <- lapply(files, process_file_earliest)

# Convert to a dataframe
results_earliest_df <- do.call(rbind, results_earliest)
results_earliest_df <- as.data.frame(results_earliest_df)

# Write to Excel
Data<-cbind(results_earliest_df,results_df)
write.xlsx(Data, file="C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Earliest_latest.xlsx")


wb <- read_excel("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/StandardList.xlsx")
wb1 <- loadWorkbook("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Earliest_latest.xlsx")

wb$earliest_planting_day<-ifelse(is.na(Data$earliest_planting_day), NA, as.numeric(Data$earliest_planting_day))
wb$latest_planting_day<-ifelse(is.na(Data$latest_planting_day), NA, as.numeric(Data$latest_planting_day))
wb$total_gdd<-ifelse(is.na(Data$total_gdd), NA, as.numeric(Data$total_gdd))

# save the changes to the Excel file
# write.xlsx(wb, file="C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Earliest_latest.xlsx", sheet="Sheet1")
write.xlsx(wb, file = "C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Earliest_latest.xlsx", sheetName = "Sheet1")


# Create a new worksheet
addWorksheet(wb1, "Sheet1")

# Add data to the new worksheet

writeData(wb1, "Sheet1",wb)

# Save the changes to the Excel file
saveWorkbook(wb1, "C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Earliest_latest.xlsx", overwrite = TRUE)


summary(Data$latest_planting_day)



# Load required libraries
library(tigris)
library(sf)
library(ggplot2)
library(dplyr)
library(readxl)
library(openxlsx)
library(maps)
library(grid)
library(scales)

# Set options
options(tigris_use_cache = TRUE)

# Load Mississippi county geometries
counties <- counties(cb = TRUE, class = "sf") %>%
  filter(STUSPS == "MS") %>%
  mutate(county_name = tolower(NAME), state_name = tolower(STATE_NAME))

# Load cotton modeling data
data <- read_excel("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Earliest_latest.xlsx", sheet = "Sheet1")
data <- as.data.frame(data)
names(data)[2] <- "county"
data$county <- tolower(data$county)
data$State <- tolower(data$State)

# Merge cotton data with county geometries
merged_data <- counties %>%
  left_join(data, by = c("county_name" = "county", "state_name" = "State"))

merged_data <- merged_data %>%
  rename(Latitude = latitude, Longitude = longitude)
merged_data$has_point <- !is.na(merged_data$Latitude)


# Filter valid planting data
merged_data$has_point <- !is.na(merged_data$Latitude)
NewData <- merged_data %>%
  select(county_name, state_name, Latitude, Longitude, earliest_planting_day, latest_planting_day, total_gdd) %>%
  filter(!is.na(Latitude)) %>%
  mutate(latest_planting_day = as.numeric(latest_planting_day)) %>%
  filter(earliest_planting_day - 6 <= latest_planting_day)

# Save lat/lon for mapped counties
SavelatlonConty <- as.data.frame(NewData[c("county_name", "state_name", "Latitude", "Longitude")])

# Mississippi base map
ms_map <- map_data("state") %>% filter(region == "mississippi")
A <- ggplot() +
  geom_polygon(data = ms_map, aes(x = long, y = lat, group = group), fill = "white", color = "black") +
  coord_fixed(1.3)

# Plot 1: Earliest Planting Day
range_earliestpltdate <- range(NewData$earliest_planting_day,na.rm = TRUE)
Fig1 <- A +
  geom_sf(data = NewData, aes(fill = earliest_planting_day)) +
  scale_fill_distiller(palette = "Spectral", limits = range_earliestpltdate, 
                       breaks = c(range_earliestpltdate[1], mean(range_earliestpltdate), range_earliestpltdate[2]),  # min, mid, max
                       labels = function(x) sprintf("%.0f", x),  # <-- round to 0 decimal places
                       name = "Earliest planting day") +
  theme_minimal() +
  labs(fill = "Earliest planting day") +
  theme(
    axis.text = element_text(size = 20),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    legend.text = element_text(size = 20),
    legend.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = unit(1, "cm")
  ) +
  xlab("Longitude") +
  ylab("Latitude") +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    ))+
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
                                  ceiling(max(st_coordinates(NewData)[,1])), 
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
                                  ceiling(max(st_coordinates(NewData)[,2])), 
                                  by = 1)) 
print(Fig1)

# Plot 2: Latest Planting Day
range_latestpltdate <- range(NewData$latest_planting_day, na.rm = TRUE)
Fig2 <- A +
  geom_sf(data = NewData, aes(fill = latest_planting_day)) +
  scale_fill_distiller(palette = "Spectral", limits = range_latestpltdate, 
                       breaks = c(range_latestpltdate[1], mean(range_latestpltdate), range_latestpltdate[2]),  # min, mid, max
                       labels = function(x) sprintf("%.0f", x),  # <-- round to 0 decimal places
                       name = "Latest planting day") +
  theme_minimal() +
  labs(fill = "Latest planting day") +
  theme(
    axis.text = element_text(size = 20),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    legend.text = element_text(size = 20),
    legend.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = unit(1, "cm")
  ) +
  xlab("Longitude") +
  ylab("Latitude") +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    ))+
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
                                  ceiling(max(st_coordinates(NewData)[,1])), 
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
                                  ceiling(max(st_coordinates(NewData)[,2])), 
                                  by = 1)) 
print(Fig2)

# Plot 3: Total GDD
range_GDD <- range(NewData$total_gdd, na.rm = TRUE)
Fig3 <- A +
  geom_sf(data = NewData, aes(fill = total_gdd)) +
  scale_fill_distiller(palette = "Spectral", limits = range_GDD,
                       breaks = c(range_GDD[1], mean(range_GDD), range_GDD[2]),  # min, mid, max
                       labels = function(x) sprintf("%.0f", x),  # <-- round to 0 decimal places
                       name = "GDD") +
  theme_minimal() +
  labs(fill = "GDD") +
  theme(
    axis.text = element_text(size = 20),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    legend.text = element_text(size = 20),
    legend.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = unit(1, "cm")
  ) +
  xlab("Longitude") +
  ylab("Latitude") +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    ))+
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
                                  ceiling(max(st_coordinates(NewData)[,1])), 
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
                                  ceiling(max(st_coordinates(NewData)[,2])), 
                                  by = 1)) 
print(Fig3)

# Plot 4: Planting Interval
range_pltint <- range(NewData$latest_planting_day-NewData$earliest_planting_day)
Fig4 <- A +
  geom_sf(data = NewData, aes(fill = latest_planting_day - earliest_planting_day)) +
  scale_fill_distiller(palette = "Spectral", limits = range_pltint, 
                       breaks = c(range_pltint[1], mean(range_pltint), range_pltint[2]),  # min, mid, max
                       labels = function(x) sprintf("%.0f", x),  # <-- round to 0 decimal places
                       name = "Planting interval") +
  theme_minimal() +
  labs(fill = "Planting interval") +
  theme(
    axis.text = element_text(size = 20),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    legend.text = element_text(size = 20),
    legend.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = unit(1, "cm")
  ) +
  xlab("Longitude") +
  ylab("Latitude") +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    ))+
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
                                  ceiling(max(st_coordinates(NewData)[,1])), 
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
                                  ceiling(max(st_coordinates(NewData)[,2])), 
                                  by = 1)) 

print(Fig4)

# Combine FQ plots
pdates <- ggarrange(Fig1, Fig2, Fig3, Fig4, nrow = 2, ncol = 2)


# Save plots
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Earliest_mid.jpeg", plot = Fig1, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Latest_mid.jpeg", plot = Fig2, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/GDD_mid.jpeg", plot = Fig3, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/PI_mid.jpeg", plot = Fig4, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/plantig_xtics_mid.jpeg", plot = pdates, width = 20, height = 20, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/plantig_xtics_mid.pdf", plot = pdates, width = 20, height = 20)


ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Earliest_mid.pdf", plot = Fig1, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Latest_mid.pdf", plot = Fig2, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/GDD_mid.pdf", plot = Fig3, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/PI_mid.pdf", plot = Fig4, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/plantig_xtics_mid.pdf", plot = pdates, width = 20, height = 20)

str(merged_data)
names(data)






library(GA)
library(readxl)
library(readr)
library(dplyr)
library(openxlsx)
library(tidyr)

# ==============================================================================
# PART 1: PHYSIOLOGICAL FUNCTIONS
# ==============================================================================

calculate_running_avg <- function(data, start_day) {
  running_avg <- numeric(length(data$Tavg))
  running_sum <- 0
  count <- 0
  for (i in seq_along(data$Tavg)) {
    if (!is.na(data$yday[i]) && data$yday[i] >= start_day) {
      if (!is.na(data$Tavg[i])) {
        running_sum <- running_sum + data$Tavg[i]
        count <- count + 1
        running_avg[i] <- running_sum / count
      } else {
        running_avg[i] <- if(count > 0) running_sum / count else NA
      }
    } else { running_avg[i] <- NA }
  }
  return(running_avg)
}

calculate_fitnessresult <- function(planting_date, weather_data, use_stress = TRUE) {
  # Prep data
  df <- weather_data %>%
    mutate(Tavg = (average_tmax + average_tmin) / 2) %>%
    arrange(yday)
  
  # Phenology Stages (Standard Thermal Logic)
  df$AvgTemp_e <- calculate_running_avg(df, planting_date)
  df <- df %>% mutate(TSQ = 190.338 - 11.372*AvgTemp_e + 0.194*AvgTemp_e^2)
  sel_sq <- df %>% filter(!is.na(TSQ) & (yday - planting_date) >= TSQ)
  if(nrow(sel_sq) == 0) return(list(TotalFitness = -9999))
  FFstartday <- min(sel_sq$yday)
  
  df$AvgTemp_s <- calculate_running_avg(df, FFstartday)
  df <- df %>% mutate(TFF = 252.591 - 15.321*AvgTemp_s + 0.2531*AvgTemp_s^2)
  sel_ff <- df %>% filter(!is.na(TFF) & (yday - FFstartday) >= TFF)
  if(nrow(sel_ff) == 0) return(list(TotalFitness = -9999))
  FOBstartday <- min(sel_ff$yday)
  
  df$AvgTemp_b <- calculate_running_avg(df, FOBstartday)
  df <- df %>% mutate(TFO = 327.396 - 17.251*AvgTemp_b + 0.255*AvgTemp_b^2)
  sel_fob <- df %>% filter(!is.na(TFO) & (yday - FOBstartday) >= TFO)
  if(nrow(sel_fob) == 0) return(list(TotalFitness = -9999))
  OpenBollDay <- min(sel_fob$yday)
  AvgTempFlowerToOB <- tail(sel_fob$AvgTemp_b, n = 1)
  
  # LWP and Stress Logic
  if (use_stress) {
    df <- df %>% mutate(LWP = -1.7727 * mean_cwsi - 1.2771)
    mean_LWP <- ...
  } else {
    mean_LWP <- NA
  }
  mean_LWP <- mean(df$LWP[df$yday >= FOBstartday & df$yday <= OpenBollDay], na.rm = TRUE)
  
  # Toggle Logic: If use_stress is FALSE, we ignore LWP effects
  if (!use_stress) {
    factor_len <- 1.0
    factor_str <- 1.0
    factor_mic <- 1.0
    factor_uni <- 1.0
  } else {
    # Apply the "Safe Zone" and Reduction Formulas
    if (!is.na(mean_LWP) && mean_LWP <= -1.45 && mean_LWP > -1.75) {
      factor_len <- 1.0
      factor_str <- 1.0
      factor_mic <- 1.0
      factor_uni <- 1.0
    } else {
      factor_len <- 1.50 + 0.309 * mean_LWP
      factor_str <- 1.35 + 0.220 * mean_LWP
      factor_mic <- 0.44 - 0.203 * mean_LWP
      factor_uni <- 1.16 + 0.098 * mean_LWP
    }
  }
  
  # Final Calculations
  T_val <- AvgTempFlowerToOB
  FStr <- (21.817 + 0.341 * T_val) * factor_str
  FLen <- (11.5 + 1.75 * T_val - 0.04 * T_val^2) * factor_len
  FMic <- (-6.88 + 0.843 * T_val - 0.017 * T_val^2) * factor_mic
  FUni <- (55.04 + 2.37 * T_val - 0.047 * T_val^2) * factor_uni
  
  return(list(TotalFitness = FStr + FLen + FMic + FUni, 
              FStrength = FStr, FLength = FLen, FMicronaire = FMic, FUniformity = FUni,
              AvgTempFtoOB = T_val, MeanLWP = mean_LWP,
              timeToSQ = FFstartday - planting_date,
              timeToFF = FOBstartday - FFstartday,
              timeToOB = OpenBollDay - FOBstartday))
}

# ==============================================================================
# PART 2: OPTIMIZATION LOOP
# ==============================================================================

# SET RUN MODE HERE: 
# TRUE = Integrated (Temp + Stress)
# FALSE = Baseline (Temp Only)
INTEGRATE_STRESS <- FALSE

weather_dir <- "C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/temp_cwsi_temp_merged"
files <- list.files(weather_dir, pattern = "*.csv", full.names = TRUE)
final_results <- data.frame()
planting_days_df <- data 

for (file in files) {
  filename <- basename(file)
  file_parts <- strsplit(filename, "_")[[1]]
  state <- file_parts[1]
  county_name_from_file <- tolower(gsub(".csv", "", file_parts[2]))
  
  matching_row <- planting_days_df[tolower(planting_days_df$county) == county_name_from_file, ]
  if(nrow(matching_row) == 0) next
  
  latest_planting_day <- as.numeric(matching_row$latest_planting_day)
  earliest_planting_day <- as.numeric(matching_row$earliest_planting_day)
  if (is.na(latest_planting_day) || is.na(earliest_planting_day)) next
  
  earliest_planting_day <- earliest_planting_day - 6
  if (earliest_planting_day >= latest_planting_day) next
  
  weather_data <- read_csv(file, show_col_types = FALSE)
  
  ga_result <- ga(
    type = "real-valued",
    fitness = function(x) calculate_fitnessresult(x, weather_data, use_stress = INTEGRATE_STRESS)$TotalFitness,
    lower = earliest_planting_day,
    upper = latest_planting_day,
    popSize = 50,
    maxiter = 100,
    run = 20,
    seed = 123
  )
  
  if(!is.null(ga_result@solution)) {
    best_date <- min(ga_result@solution[, 1])
    best_q <- calculate_fitnessresult(best_date, weather_data, use_stress = INTEGRATE_STRESS)
    
    final_results <- rbind(final_results, data.frame(
      State = state, County = county_name_from_file, PLtDate = best_date,
      FStrength = best_q$FStrength, FLength = best_q$FLength,
      FMicronaire = best_q$FMicronaire, FUniformity = best_q$FUniformity,
      AvgTempFtoOB = best_q$AvgTempFtoOB, MeanLWP = best_q$MeanLWP,
      StressUsed = INTEGRATE_STRESS
    ))
  }
}

# Verify before saving:
print(nrow(final_results)) 

# Save
write.xlsx(final_results, "C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Final_GA_Results_LWP_Estimated.xlsx")






# ===============================================================
# LIBRARIES
# ===============================================================
library(tigris)
library(sf)
library(ggplot2)
library(dplyr)
library(readxl)
library(ggpubr)

options(tigris_use_cache = TRUE)

# ===============================================================
# LOAD MISSISSIPPI COUNTY GEOMETRIES (sf)
# ===============================================================
counties_sf <- counties(cb = TRUE, class = "sf") %>%
  filter(STUSPS == "MS") %>%
  mutate(
    county = tolower(NAME),
    state  = tolower(STATE_NAME)
  )
# ===============================================================
# LOAD GA RESULTS
# ===============================================================
data <- read_excel(
  "C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/Final_GA_Results_LWP_Estimated.xlsx"
)

# Clean column names
colnames(data) <- trimws(colnames(data))
data <- data %>% rename_with(tolower)

# Standardize text
data <- data %>%
  mutate(
    county = tolower(county),
    state  = tolower(state)
  )

# ===============================================================
# MERGE SPATIAL + GA RESULTS
# ===============================================================
NewData <- counties_sf %>%
  left_join(data, by = c("county", "state")) %>%
  filter(!is.na(pltdate))   # Keep only modeled counties


# ===============================================================
# ENSURE NUMERIC COLUMNS (prevents plotting errors)
# ===============================================================
# numeric_cols <- c("pltdate","fstrength","flength",
#                   "fmicronaire","funiformity",
#                   "avgtempftoob")
# 
# NewData[numeric_cols] <- lapply(NewData[numeric_cols], as.numeric)

# ===============================================================
# DEFINE SAFE COLOR RANGES
# ===============================================================
range_FQM  <- range(NewData$fmicronaire,  na.rm = TRUE)
range_FQL  <- range(NewData$flength,      na.rm = TRUE)
range_FQU  <- range(NewData$funiformity,  na.rm = TRUE)
range_FQS  <- range(NewData$fstrength,    na.rm = TRUE)
range_PLt  <- range(NewData$pltdate,      na.rm = TRUE)
range_TEMP <- range(NewData$avgtempftoob, na.rm = TRUE)


# ===============================================================
# COMMON THEME
# ===============================================================
# 1. Define the Visual Style only
common_style <- theme_minimal() + 
  theme(
    axis.text = element_text(size = 20),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    legend.text = element_text(size = 20),
    legend.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = unit(1, "cm")
  )

# 2. Define a list of Shared Layers (Scales, Guides, Labels)
common_layers <- list(
  xlab("Longitude"),
  ylab("Latitude"),
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    )
  ),
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])),
                                  ceiling(max(st_coordinates(NewData)[,1])),
                                  by = 1)),
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])),
                                  ceiling(max(st_coordinates(NewData)[,2])),
                                  by = 1))
)


# ===============================================================
# PLOTS
# ===============================================================

# 1️⃣ Micronaire
Fig1 <- ggplot(NewData) +
  geom_sf(aes(fill = fmicronaire), color = "black", size = 0.2) +
  scale_fill_distiller(palette = "Spectral",
                       limits = range_FQM,
                       name = "Micronaire",
                       breaks = c(range_FQM[1], mean(range_FQM), range_FQM[2]),
                       labels = function(x) sprintf("%.1f", x)) +
  common_style +   # Add the theme
  common_layers    # Add the labels/scales/guides

# 2️⃣ Fiber Length
Fig2 <- ggplot(NewData) +
  geom_sf(aes(fill = flength), color = "black", size = 0.2) +
  scale_fill_distiller(palette = "Spectral",
                       limits = range_FQL,
                       name = "Fiber Length (mm)",
                       breaks = c(range_FQL[1], mean(range_FQL), range_FQL[2]),
                       labels = function(x) sprintf("%.1f", x)) +
  common_style +   # Add the theme
  common_layers    # Add the labels/scales/guides common_theme

# 3️⃣ Uniformity
Fig3 <- ggplot(NewData) +
  geom_sf(aes(fill = funiformity), color = "black", size = 0.2) +
  scale_fill_distiller(palette = "Spectral",
                       limits = range_FQU,
                       name = "Fiber Uniformity (%)",
                       breaks = c(range_FQU[1], mean(range_FQU), range_FQU[2]),
                       labels = function(x) sprintf("%.1f", x)) +
  common_style +   # Add the theme
  common_layers    # Add the labels/scales/guides

# 4️⃣ Strength
Fig4 <- ggplot(NewData) +
  geom_sf(aes(fill = fstrength), color = "black", size = 0.2) +
  scale_fill_distiller(palette = "Spectral",
                       limits = range_FQS,
                       name = "Fiber Strength (g tex⁻¹)",
                       breaks = c(range_FQS[1], mean(range_FQS), range_FQS[2]),
                       labels = function(x) sprintf("%.1f", x)) +
  common_style +   # Add the theme
  common_layers    # Add the labels/scales/guides

# 5️⃣ Planting Date
Fig5 <- ggplot(NewData) +
  geom_sf(aes(fill = pltdate), color = "black", size = 0.2) +
  scale_fill_distiller(palette = "Spectral",
                       limits = range_PLt,
                       name = "Planting Day (DOY)",
                       breaks = c(range_PLt[1], mean(range_PLt), range_PLt[2]),
                       labels = function(x) sprintf("%.0f", x)) +
  common_style +   # Add the theme
  common_layers    # Add the labels/scales/guides

# 6️⃣ Avg Temp Flower → Open Boll
Fig6 <- ggplot(NewData) +
  geom_sf(aes(fill = avgtempftoob), color = "black", size = 0.2) +
  scale_fill_distiller(palette = "Spectral",
                       limits = range_TEMP,
                       name = "Avg Temp (°C)",
                       breaks = c(range_TEMP[1], mean(range_TEMP), range_TEMP[2]),
                       labels = function(x) sprintf("%.1f", x)) +
  common_style +   # Add the theme
  common_layers    # Add the labels/scales/guides



# ===============================================================
# DISPLAY
# ===============================================================
Fig1
Fig2
Fig3
Fig4
Fig5
Fig6


# ===============================================================
# COMBINED FIGURES
# ===============================================================
FQ <- ggarrange(Fig1, Fig2, Fig3,
                Fig4, Fig5, Fig6,
                nrow = 2, ncol = 3)

Temp_pday <- ggarrange(Fig5, Fig6, nrow = 1, ncol = 2)

# ===============================================================
# SAVE OUTPUTS
# ===============================================================
output_dir <- "C:/Users/jnm533/Desktop/Reddy cotton work/CWSI Results/"

ggsave(paste0(output_dir, "Micronaire_mid.jpeg"), Fig1, width = 10, height = 10)
ggsave(paste0(output_dir, "Length_mid.jpeg"), Fig2, width = 10, height = 10)
ggsave(paste0(output_dir, "Uniformity_mid.jpeg"), Fig3, width = 10, height = 10)
ggsave(paste0(output_dir, "Strength_mid.jpeg"), Fig4, width = 10, height = 10)
ggsave(paste0(output_dir, "PlantingDay_mid.jpeg"), Fig5, width = 10, height = 10)
ggsave(paste0(output_dir, "AvgTemp_mid.jpeg"), Fig6, width = 10, height = 10)


ggsave(paste0(output_dir, "FQ_Combined_mid.jpeg"), FQ,
       width = 30, height = 20, dpi = 300)

ggsave(paste0(output_dir, "FQ_Combined_mid.pdf"), FQ,
       width = 30, height = 20)

ggsave(paste0(output_dir, "Temp_vs_Planting_mid.jpeg"),
       Temp_pday, width = 20, height = 15)

message("All plots successfully generated and saved.")
