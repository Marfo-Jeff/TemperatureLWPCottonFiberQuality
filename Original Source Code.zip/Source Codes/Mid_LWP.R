library(readxl)
library(readr)
library(ggplot2)
library(dplyr)
library(RColorBrewer)
library(plotly)
library(lubridate)
library(ggpubr)
library(openxlsx)
library(grid)
library(tidyr)
library(tidyverse)
library(scales)
library(stringr) 
library(reshape2)
library(ggtext)
library("maps")
library(tigris)
library(sf)
library(openxlsx)

# LATEST PLANTING DATE----

process_file <- function(file_path) {
  # Read the CSV file
  data <- read_csv(file_path, show_col_types = FALSE)
  print(names(data))
  
  # Extract latitude and longitude from the first row
  latitude <- data$latitude[1]
  longitude <- data$longitude[1]
  
  # Reverse the data for backward accumulation
  data <- data[nrow(data):1, ]
  
  # Initialize variables
  accumulated_gdd <- 0
  latest_planting_day <- NA
  
  # Loop through each row backwards to calculate GDD and accumulate
  for (i in 1:nrow(data)) {
    avg_temp <- (data$average_tmax[i] + data$average_tmin[i]) / 2
    
    daily_gdd <- max(((9/5) * avg_temp + 32) - 60, 0)
    accumulated_gdd <- accumulated_gdd + daily_gdd
    
    if (accumulated_gdd >= 2400) {
      latest_planting_day <- data$yday[i]
      break
    }
  }
  
  return(list(
    file = file_path,
    latitude = latitude,
    longitude = longitude,
    latest_planting_day = latest_planting_day,
    total_gdd = accumulated_gdd
  ))
}



# Assuming all your files are in a directory "data_files"
files <- list.files(path = "C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/temp_cwsi_joined_csv", full.names = TRUE)

# Process each file
results <- lapply(files, process_file)

# Convert to a dataframe for easier viewing/manipulation
results_df <- do.call(rbind, results)
results_df<-as.data.frame(results_df)

# Check and handle NA values in the dataframe
results_df[is.na(results_df)] <- "NA"  # Replace NA with "NA" or another placeholder


#write.xlsx(results_df, file="C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/latest_early.xlsx")

#FIRST PLATNING DATE----
process_file_earliest <- function(file_path) {
  
  # Read the CSV file
  data <- read_csv(file_path, show_col_types = FALSE)
  print(names(data))
  
  
  # Extract latitude and longitude from the first row
  latitude <- data$latitude[1]
  longitude <- data$longitude[1]
  
  # Initialize variables
  consecutive_days_above_15 <- 0
  earliest_planting_day <- NA
  
  # Loop through each row to check average temperature
  for (i in 1:nrow(data)) {
    avg_temp <- (data$average_tmax[i] + data$average_tmin[i]) / 2
    
    # Updated: Include soil moisture condition for planting window
    if (avg_temp >= 15) {
      consecutive_days_above_15 <- consecutive_days_above_15 + 1
      if (consecutive_days_above_15 >= 7) {
        earliest_planting_day <- data$yday[i]
        break
      }
    } else {
      consecutive_days_above_15 <- 0  # Reset count if temperature drops below 15
    }
  }
  
  return(list(file = file_path, latitude = latitude, longitude = longitude, earliest_planting_day = earliest_planting_day))
}

# Process each file for earliest planting date
results_earliest <- lapply(files, process_file_earliest)

# Convert to a dataframe
results_earliest_df <- do.call(rbind, results_earliest)
results_earliest_df <- as.data.frame(results_earliest_df)

# Write to Excel
Data<-cbind(results_earliest_df,results_df)
write.xlsx(Data, file="C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/latest_early.xlsx")


wb <- read_excel("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/StandardList.xlsx")
wb1 <- loadWorkbook("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/latest_early.xlsx")

wb$earliest_planting_day<-ifelse(is.na(Data$earliest_planting_day), NA, as.numeric(Data$earliest_planting_day))
wb$latest_planting_day<-ifelse(is.na(Data$latest_planting_day), NA, as.numeric(Data$latest_planting_day))
wb$total_gdd<-ifelse(is.na(Data$total_gdd), NA, as.numeric(Data$total_gdd))

# save the changes to the Excel file
# write.xlsx(wb, file="C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/latest_early.xlsx", sheet="Sheet1")
write.xlsx(wb, file = "C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/latest_early.xlsx", sheetName = "Sheet1")


# Create a new worksheet
addWorksheet(wb1, "Sheet1")

# Add data to the new worksheet

writeData(wb1, "Sheet1",wb)

# Save the changes to the Excel file
saveWorkbook(wb1, "C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/latest_early.xlsx", overwrite = TRUE)


summary(Data$latest_planting_day)



# Load required libraries
library(tigris)
library(sf)
library(ggplot2)
library(dplyr)
library(readxl)
library(openxlsx)
library(maps)
library(grid)
library(scales)

# Set options
options(tigris_use_cache = TRUE)

# Load Mississippi county geometries
counties <- counties(cb = TRUE, class = "sf") %>%
  filter(STUSPS == "MS") %>%
  mutate(county_name = tolower(NAME), state_name = tolower(STATE_NAME))

# Load cotton modeling data
data <- read_excel("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/latest_early.xlsx", sheet = "Sheet1")
data <- as.data.frame(data)
names(data)[2] <- "county"
data$county <- tolower(data$county)
data$State <- tolower(data$State)

# Merge cotton data with county geometries
merged_data <- counties %>%
  left_join(data, by = c("county_name" = "county", "state_name" = "State"))

merged_data <- merged_data %>%
  rename(Latitude = latitude, Longitude = longitude)
merged_data$has_point <- !is.na(merged_data$Latitude)


# Filter valid planting data
merged_data$has_point <- !is.na(merged_data$Latitude)
NewData <- merged_data %>%
  select(county_name, state_name, Latitude, Longitude, earliest_planting_day, latest_planting_day, total_gdd) %>%
  filter(!is.na(Latitude)) %>%
  mutate(latest_planting_day = as.numeric(latest_planting_day)) %>%
  filter(earliest_planting_day - 6 <= latest_planting_day)

# Save lat/lon for mapped counties
SavelatlonConty <- as.data.frame(NewData[c("county_name", "state_name", "Latitude", "Longitude")])

# Mississippi base map
ms_map <- map_data("state") %>% filter(region == "mississippi")
A <- ggplot() +
  geom_polygon(data = ms_map, aes(x = long, y = lat, group = group), fill = "white", color = "black") +
  coord_fixed(1.3)

# Plot 1: Earliest Planting Day
range_earliestpltdate <- range(NewData$earliest_planting_day,na.rm = TRUE)
Fig1 <- A +
  geom_sf(data = NewData, aes(fill = earliest_planting_day)) +
  scale_fill_distiller(palette = "Spectral", limits = range_earliestpltdate, 
                       breaks = c(range_earliestpltdate[1], mean(range_earliestpltdate), range_earliestpltdate[2]),  # min, mid, max
                       labels = function(x) sprintf("%.0f", x),  # <-- round to 0 decimal places
                       name = "Earliest planting day") +
  theme_minimal() +
  labs(fill = "Earliest planting day") +
  theme(
    axis.text = element_text(size = 20),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    legend.text = element_text(size = 20),
    legend.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = unit(1, "cm")
  ) +
  xlab("Longitude") +
  ylab("Latitude") +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    ))+
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
                                  ceiling(max(st_coordinates(NewData)[,1])), 
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
                                  ceiling(max(st_coordinates(NewData)[,2])), 
                                  by = 1)) 
print(Fig1)

# Plot 2: Latest Planting Day
range_latestpltdate <- range(NewData$latest_planting_day, na.rm = TRUE)
Fig2 <- A +
  geom_sf(data = NewData, aes(fill = latest_planting_day)) +
  scale_fill_distiller(palette = "Spectral", limits = range_latestpltdate, 
                       breaks = c(range_latestpltdate[1], mean(range_latestpltdate), range_latestpltdate[2]),  # min, mid, max
                       labels = function(x) sprintf("%.0f", x),  # <-- round to 0 decimal places
                       name = "Latest planting day") +
  theme_minimal() +
  labs(fill = "Latest planting day") +
  theme(
    axis.text = element_text(size = 20),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    legend.text = element_text(size = 20),
    legend.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = unit(1, "cm")
  ) +
  xlab("Longitude") +
  ylab("Latitude") +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    ))+
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
                                  ceiling(max(st_coordinates(NewData)[,1])), 
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
                                  ceiling(max(st_coordinates(NewData)[,2])), 
                                  by = 1)) 
print(Fig2)

# Plot 3: Total GDD
range_GDD <- range(NewData$total_gdd, na.rm = TRUE)
Fig3 <- A +
  geom_sf(data = NewData, aes(fill = total_gdd)) +
  scale_fill_distiller(palette = "Spectral", limits = range_GDD,
                       breaks = c(range_GDD[1], mean(range_GDD), range_GDD[2]),  # min, mid, max
                       labels = function(x) sprintf("%.0f", x),  # <-- round to 0 decimal places
                       name = "GDD") +
  theme_minimal() +
  labs(fill = "GDD") +
  theme(
    axis.text = element_text(size = 20),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    legend.text = element_text(size = 20),
    legend.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = unit(1, "cm")
  ) +
  xlab("Longitude") +
  ylab("Latitude") +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    ))+
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
                                  ceiling(max(st_coordinates(NewData)[,1])), 
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
                                  ceiling(max(st_coordinates(NewData)[,2])), 
                                  by = 1)) 
print(Fig3)

# Plot 4: Planting Interval
range_pltint <- range(NewData$latest_planting_day-NewData$earliest_planting_day)
Fig4 <- A +
  geom_sf(data = NewData, aes(fill = latest_planting_day - earliest_planting_day)) +
  scale_fill_distiller(palette = "Spectral", limits = range_pltint, 
                       breaks = c(range_pltint[1], mean(range_pltint), range_pltint[2]),  # min, mid, max
                       labels = function(x) sprintf("%.0f", x),  # <-- round to 0 decimal places
                       name = "Planting interval") +
  theme_minimal() +
  labs(fill = "Planting interval") +
  theme(
    axis.text = element_text(size = 20),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    legend.text = element_text(size = 20),
    legend.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = unit(1, "cm")
  ) +
  xlab("Longitude") +
  ylab("Latitude") +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    ))+
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
                                  ceiling(max(st_coordinates(NewData)[,1])), 
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
                                  ceiling(max(st_coordinates(NewData)[,2])), 
                                  by = 1)) 

print(Fig4)

# Combine FQ plots
pdates <- ggarrange(Fig1, Fig2, Fig3, Fig4, nrow = 2, ncol = 2)


# Save plots
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Earliest_mid.jpeg", plot = Fig1, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Latest_mid.jpeg", plot = Fig2, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/GDD_mid.jpeg", plot = Fig3, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/PI_mid.jpeg", plot = Fig4, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/plantig_xtics_mid.jpeg", plot = pdates, width = 20, height = 20, dpi = 500)

ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Earliest_mid.pdf", plot = Fig1, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Latest_mid.pdf", plot = Fig2, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/GDD_mid.pdf", plot = Fig3, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/PI_mid.pdf", plot = Fig4, width = 10, height = 10, dpi = 300)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/plantig_xtics_mid.pdf", plot = pdates, width = 20, height = 20)

str(merged_data)
names(data)






library(GA)
library(readxl)
library(readr)
library(dplyr)
library(openxlsx)
library(tidyr)

# ==============================================================================
# PART 1: PHYSIOLOGICAL FUNCTIONS
# ==============================================================================

calculate_running_avg <- function(data, start_day) {
  running_avg <- numeric(length(data$Tavg))
  running_sum <- 0
  count <- 0
  for (i in seq_along(data$Tavg)) {
    if (!is.na(data$yday[i]) && data$yday[i] >= start_day) {
      if (!is.na(data$Tavg[i])) {
        running_sum <- running_sum + data$Tavg[i]
        count <- count + 1
        running_avg[i] <- running_sum / count
      } else {
        running_avg[i] <- if(count > 0) running_sum / count else NA
      }
    } else { running_avg[i] <- NA }
  }
  return(running_avg)
}

calculate_fitnessresult <- function(planting_date, weather_data) {
  # Prep data
  df <- weather_data %>%
    mutate(Tavg = (average_tmax + average_tmin) / 2) %>%
    arrange(yday)
  
  # Stage 1: TFS (Time from Sowing to Squaring)
  df$AvgTemp_e <- calculate_running_avg(df, planting_date)
  df <- df %>% mutate(TSQ = 190.338 - 11.372*AvgTemp_e + 0.194*AvgTemp_e^2)
  sel_sq <- df %>% filter(!is.na(TSQ) & (yday - planting_date) >= TSQ)
  if(nrow(sel_sq) == 0) return(list(TotalFitness = -9999))
  FFstartday <- min(sel_sq$yday)
  
  # Stage 2: TFF (Time from Squaring to Flowering)
  df$AvgTemp_s <- calculate_running_avg(df, FFstartday)
  df <- df %>% mutate(TFF = 252.591 - 15.321*AvgTemp_s + 0.2531*AvgTemp_s^2)
  sel_ff <- df %>% filter(!is.na(TFF) & (yday - FFstartday) >= TFF)
  if(nrow(sel_ff) == 0) return(list(TotalFitness = -9999))
  FOBstartday <- min(sel_ff$yday)
  
  # Stage 3: TFO (Time from Flowering to Open Boll)
  df$AvgTemp_b <- calculate_running_avg(df, FOBstartday)
  df <- df %>% mutate(TFO = 327.396 - 17.251*AvgTemp_b + 0.255*AvgTemp_b^2)
  sel_fob <- df %>% filter(!is.na(TFO) & (yday - FOBstartday) >= TFO)
  if(nrow(sel_fob) == 0) return(list(TotalFitness = -9999))
  OpenBollDay <- min(sel_fob$yday)
  AvgTempFlowerToOB <- tail(sel_fob$AvgTemp_b, n = 1)
  
  # ------------------------------------------------------------------------------
  # LWP EQUATION CONSTANTS (Cohen et al., 2015)
  # LWP (MPa) = COHEN_SLOPE * CWSI + COHEN_INTERCEPT
  # Calibration valid for Tmax <= CALIB_TEMP_MAX; flag extrapolation beyond this.
  # ------------------------------------------------------------------------------
  COHEN_SLOPE     <- -1.7727
  COHEN_INTERCEPT <- -1.2771
  CALIB_TEMP_MAX  <- 39.0

  # LWP Estimation
  df <- df %>% mutate(
    LWP             = COHEN_SLOPE * mean_cwsi + COHEN_INTERCEPT,
    LWP_extrapolated = average_tmax > CALIB_TEMP_MAX
  )
  
  # Mean LWP during Flowering to Open Boll
  mean_LWP <- mean(df$LWP[df$yday >= FOBstartday & df$yday <= OpenBollDay], na.rm = TRUE)
  
  # ==========================================================================
  # REDUCTION FACTOR LOGIC WITH SAFE ZONE
  # ==========================================================================
  # If LWP is between -1.45 and -1.75, no reduction is applied (factors = 1)
  # Otherwise, use the linear equations.
  # Reduction factors clipped to [0, 1] to prevent biologically implausible values.
  
  if (!is.na(mean_LWP) && mean_LWP <= -1.45 && mean_LWP > -1.75) {
    factor_len <- 1.0
    factor_str <- 1.0
    factor_mic <- 1.0
    factor_uni <- 1.0
  } else {
    factor_len <- pmin(1.0, pmax(0, 1.50 + 0.309 * mean_LWP))
    factor_str <- pmin(1.0, pmax(0, 1.35 + 0.220 * mean_LWP))
    factor_mic <- pmin(1.0, pmax(0, 0.44 - 0.203 * mean_LWP))
    factor_uni <- pmin(1.0, pmax(0, 1.16 + 0.098 * mean_LWP))
  }

  # LWP stress class (upper-inclusive boundaries)
  classify_lwp <- function(lwp) {
    dplyr::case_when(
      lwp >  -1.45                 ~ "Over-irrigated",
      lwp >  -1.75 & lwp <= -1.45 ~ "Well-watered",
      lwp >  -2.05 & lwp <= -1.75 ~ "Low stress",
      lwp >  -2.35 & lwp <= -2.05 ~ "Medium stress",
      lwp <= -2.35                 ~ "Severe stress",
      TRUE                         ~ NA_character_
    )
  }
  
  # Final Quality Calculations
  T_val <- AvgTempFlowerToOB
  
  FStr <- (21.817 + 0.341 * T_val) * factor_str
  FLen <- (11.5 + 1.75 * T_val - 0.04 * T_val^2) * factor_len
  FMic <- (-6.88 + 0.843 * T_val - 0.017 * T_val^2) * factor_mic
  FUni <- (55.04 + 2.37 * T_val - 0.047 * T_val^2) * factor_uni
  
  return(list(TotalFitness = FStr + FLen + FMic + FUni, 
              FStrength = FStr, 
              FLength = FLen, 
              FMicronaire = FMic, 
              FUniformity = FUni,
              AvgTempFtoOB = T_val, 
              MeanLWP = mean_LWP,
              timeToSQ = FFstartday - planting_date,
              timeToFF = FOBstartday - FFstartday,
              timeToOB = OpenBollDay - FOBstartday))
}

# ==============================================================================
# PART 2: OPTIMIZATION LOOP
# ==============================================================================

weather_dir <- "C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/temp_cwsi_joined_csv"
files <- list.files(weather_dir, pattern = "*.csv", full.names = TRUE)
final_results <- data.frame()
planting_days_df <- data 

for (file in files) {
  filename <- basename(file)
  file_parts <- strsplit(filename, "_")[[1]]
  state <- file_parts[1]
  county_name_from_file <- tolower(gsub(".csv", "", file_parts[2]))
  
  matching_row <- planting_days_df[tolower(planting_days_df$county) == county_name_from_file, ]
  
  if(nrow(matching_row) == 0) {
    message(paste("Skipping: No boundary match for", county_name_from_file))
    next
  }
  
  latest_planting_day <- as.numeric(matching_row$latest_planting_day)
  earliest_planting_day <- as.numeric(matching_row$earliest_planting_day)
  
  if (is.na(latest_planting_day) || is.na(earliest_planting_day)) {
    message("Skipping (NA planting window): ", county_name_from_file)
    next
  }
  
  earliest_planting_day <- earliest_planting_day - 6
  
  if (earliest_planting_day >= latest_planting_day) {
    message("Skipping (invalid window): ", county_name_from_file)
    next
  }
  
  weather_data <- read_csv(file, show_col_types = FALSE)
  
  ga_result <- ga(
    type = "real-valued",
    fitness = function(x) calculate_fitnessresult(x, weather_data)$TotalFitness,
    lower = earliest_planting_day,
    upper = latest_planting_day,
    popSize = 50,
    maxiter = 100,
    run = 20,
    seed = 123
  )
  
  if(!is.null(ga_result@solution)) {
    best_date <- min(ga_result@solution[, 1])
    best_q <- calculate_fitnessresult(best_date, weather_data)
    
    final_results <- rbind(final_results, data.frame(
      State = state, 
      County = county_name_from_file,
      PLtDate = best_date,
      FStrength = best_q$FStrength,
      FLength = best_q$FLength,
      FMicronaire = best_q$FMicronaire,
      FUniformity = best_q$FUniformity,
      AvgTempFtoOB = best_q$AvgTempFtoOB,
      timeToSQ = best_q$timeToSQ,
      timeToFF = best_q$timeToFF,
      timeToOB = best_q$timeToOB,
      MeanLWP = best_q$MeanLWP,
      Lat = weather_data$latitude[1],
      Lon = weather_data$longitude[1]
    ))
  }
}

# Verify before saving:
print(nrow(final_results)) 

# Save
write.xlsx(final_results, "C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Final_GA_Results_LWP_Estimated.xlsx")






# Load required libraries
library(tigris)
library(sf)
library(ggplot2)
library(dplyr)
library(readxl)
library(openxlsx)
library(maps)
library(grid)
library(scales)
library(ggpubr)

# Set options
options(tigris_use_cache = TRUE)

# Load Mississippi county geometries
counties <- counties(cb = TRUE, class = "sf") %>%
  filter(STUSPS == "MS") %>%
  mutate(county_name = tolower(NAME), state_name = tolower(STATE_NAME))

# Load cotton modeling data
data <- read_excel("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Final_GA_Results_LWP_Estimated.xlsx")
data <- as.data.frame(data)
names(data)[2] <- "county"
data$county <- tolower(data$county)
data$State <- tolower(data$State)

# Merge cotton data with county geometries
merged_data <- counties %>%
  left_join(data, by = c("county_name" = "county", "state_name" = "State"))

merged_data <- merged_data %>%
  rename(Latitude = Lat, Longitude = Lon)
merged_data$has_point <- !is.na(merged_data$Latitude)


# 1. Filter and select only the columns that actually exist in your GA results file
NewData <- merged_data %>%
  select(county_name, state_name, Latitude, Longitude, PLtDate, 
         FMicronaire, FStrength, FLength, FUniformity, AvgTempFtoOB, MeanLWP) %>%
  filter(!is.na(Latitude))

# 2. THE FIX: Convert the list/matrix columns into simple numeric vectors
# This prevents the "Inf / -Inf" and "not numeric" errors
NewData$PLtDate <- as.numeric(unlist(NewData$PLtDate))
NewData$FMicronaire <- as.numeric(unlist(NewData$FMicronaire))
NewData$FStrength <- as.numeric(unlist(NewData$FStrength))
NewData$FLength <- as.numeric(unlist(NewData$FLength))
NewData$FUniformity <- as.numeric(unlist(NewData$FUniformity))
NewData$AvgTempFtoOB <- as.numeric(unlist(NewData$AvgTempFtoOB))
NewData$MeanLWP <- as.numeric(unlist(NewData$MeanLWP))


# 3. Define your ranges for the color scales 
range_FQM <- range(NewData$FMicronaire, na.rm = TRUE)
range_FQL <- range(NewData$FLength, na.rm = TRUE)
range_FQU <- range(NewData$FUniformity, na.rm = TRUE)
range_FQS <- range(NewData$FStrength, na.rm = TRUE)
range_PLtDate <- range(NewData$PLtDate, na.rm = TRUE)
range_AvgTempFtoOB <- range(NewData$AvgTempFtoOB, na.rm = TRUE)
range_LWP <- range(NewData$MeanLWP, na.rm = TRUE)


# NewData <- merged_data %>%
#   select(county_name, state_name, Latitude, Longitude, PLtDate, FMicronaire,
#          FStrength, FLength, FUniformity, timeToSQ, timeToFF, timeToOB, AvgTempFtoOB) %>%
#   filter(!is.na(Latitude))



# Save lat/lon for mapped counties
SavelatlonConty <- as.data.frame(NewData[c("county_name", "state_name", "Latitude", "Longitude")])

# Mississippi base map
ms_map <- map_data("state") %>% filter(region == "mississippi")
A <- ggplot() +
  geom_polygon(data = ms_map, aes(x = long, y = lat, group = group), fill = "white", color = "black") +
  coord_fixed(1.3)

# Define ranges
range_FQM <- c(min(NewData$FMicronaire), max(NewData$FMicronaire))
range_FQL <- c(min(NewData$FLength), max(NewData$FLength))
range_FQU <- c(min(NewData$FUniformity), max(NewData$FUniformity))
range_FQS <- c(min(NewData$FStrength), max(NewData$FStrength))
range_PLtDate <- c(min(NewData$PLtDate), max(NewData$PLtDate))
range_AvgTempFtoOB <- c(min(NewData$AvgTempFtoOB), max(NewData$AvgTempFtoOB))



library(classInt)
library(RColorBrewer)

# # Jenks breaks for each fiber quality metric
# jenks_breaks <- classIntervals(NewData$FMicronaire, n = 5, style = "jenks")$brks
# jenks_breaks_length <- classIntervals(NewData$FLength, n = 5, style = "jenks")$brks
# jenks_breaks_uniformity <- classIntervals(NewData$FUniformity, n = 5, style = "jenks")$brks
# jenks_breaks_strength <- classIntervals(NewData$FStrength, n = 5, style = "jenks")$brks
# jenks_breaks_pdate <- classIntervals(NewData$PLtDate, n = 5, style = "jenks")$brks


# Plot 1: Micronaire
Fig5 <- A +
  geom_sf(data = NewData, aes(fill = FMicronaire)) +
  scale_fill_distiller(palette = "Spectral", limits = range_FQM,
                       breaks = c(range_FQM[1], mean(range_FQM), range_FQM[2]),  # min, mid, max
                       labels = function(x) sprintf("%.1f", x),  # <-- round to 0 decimal places
                       name = "Micronaire") +
  theme_minimal() +
  labs(fill = "Micronaire") +
  theme(axis.text = element_text(size = 20),
        axis.title.x = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        legend.text = element_text(size = 20),
        legend.title = element_text(size = 20),
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.key.width = unit(1, "cm")) +
  xlab("Longitude") + ylab("Latitude") +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    )
  )+
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])),
                                  ceiling(max(st_coordinates(NewData)[,1])),
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])),
                                  ceiling(max(st_coordinates(NewData)[,2])),
                                  by = 1))


# Fig1 <- A +
#   geom_sf(data = NewData, aes(fill = cut(FMicronaire, breaks = jenks_breaks, include.lowest = TRUE))) +
#   scale_fill_brewer(palette = "Spectral", direction = -1, name = "Micronaire") +
#   theme_minimal() +
#   labs(fill = "Micronaire") +
#   theme(axis.text = element_text(size = 10),
#         axis.title.x = element_text(size = 12),
#         axis.title.y = element_text(size = 12),
#         legend.text = element_text(size = 10),
#         legend.title = element_text(size = 12),
#         legend.position = "bottom",
#         legend.direction = "horizontal",
#         legend.key.width = unit(1, "cm")) +
#   xlab("Longitude") + ylab("Latitude") +
#   guides(fill = guide_legend(nrow = 1)) +
#   scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
#                                   ceiling(max(st_coordinates(NewData)[,1])), 
#                                   by = 1)) +
#   scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
#                                   ceiling(max(st_coordinates(NewData)[,2])), 
#                                   by = 1))


# Plot 2: Fiber Length
Fig6 <- A +
  geom_sf(data = NewData, aes(fill = FLength)) +
  scale_fill_distiller(
    palette = "Spectral",
    limits = range_FQL,
    breaks = c(range_FQL[1], mean(range_FQL), range_FQL[2]),  # min, mid, max
    labels = function(x) sprintf("%.1f", x),  # <-- round to 0 decimal places
    name = "Fiber Length (mm)"
  ) +
  coord_sf(expand = FALSE) +
  theme_minimal() +
  theme(
    axis.text = element_text(size = 20),
    axis.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.title = element_text(size = 20),
    legend.text = element_text(size = 20),
    plot.margin = margin(10, 10, 25, 10),
    legend.box.margin = margin(t = -10)
  ) +
  guides(
    fill = guide_colorbar(
      barwidth = 20,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    )
  ) +
  xlab("Longitude") + ylab("Latitude") +
  scale_x_continuous(
    breaks = seq(
      floor(min(st_coordinates(NewData)[,1])),
      ceiling(max(st_coordinates(NewData)[,1])),
      by = 1
    )
  ) +
  scale_y_continuous(
    breaks = seq(
      floor(min(st_coordinates(NewData)[,2])),
      ceiling(max(st_coordinates(NewData)[,2])),
      by = 1
    )
  )



# Plot 3: Uniformity
Fig7 <- A +
  geom_sf(data = NewData, aes(fill = FUniformity)) +
  scale_fill_distiller(
    palette = "Spectral",
    limits = range_FQU,
    breaks = c(range_FQU[1], mean(range_FQU), range_FQU[2]),  # min, mid, max
    labels = function(x) sprintf("%.1f", x),  # <-- round to 0 decimal places
    name = "Fiber Uniformity (%)"
  ) +
  coord_sf(expand = FALSE) +
  theme_minimal() +
  theme(
    axis.text = element_text(size = 20),
    axis.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.title = element_text(size = 20, margin = margin(b = 6)),
    legend.text = element_text(size = 20),
    plot.margin = margin(10, 10, 25, 10),
    legend.box.margin = margin(t = -10)
  ) +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    )
  ) +
  xlab("Longitude") + ylab("Latitude") +
  scale_x_continuous(
    breaks = seq(
      floor(min(st_coordinates(NewData)[,1])),
      ceiling(max(st_coordinates(NewData)[,1])),
      by = 1
    )
  ) +
  scale_y_continuous(
    breaks = seq(
      floor(min(st_coordinates(NewData)[,2])),
      ceiling(max(st_coordinates(NewData)[,2])),
      by = 1
    )
  )


# Plot 4: Strength
Fig8 <- A +
  geom_sf(data = NewData, aes(fill = FStrength), color = "black", size = 0.2) +
  scale_fill_distiller(
    palette = "Spectral",
    limits = range_FQS,
    breaks = c(range_FQS[1], mean(range_FQS), range_FQS[2]),  # min, mid, max
    labels = function(x) sprintf("%.1f", x),  # <-- round to 0 decimal places
    name = "Fiber Strength (g tex-1)"
  ) +
  coord_sf(expand = FALSE) +
  theme_minimal() +
  theme(axis.text = element_text(size = 20),
        axis.title.x = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        legend.text = element_text(size = 20),
        legend.title = element_text(size = 20),
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.key.width = unit(1, "cm")) +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    )
  ) +
  xlab("Longitude") + ylab("Latitude")+
  scale_x_continuous(
    breaks = seq(
      floor(min(st_coordinates(NewData)[,1])),
      ceiling(max(st_coordinates(NewData)[,1])),
      by = 1
    )
  ) +
  scale_y_continuous(
    breaks = seq(
      floor(min(st_coordinates(NewData)[,2])),
      ceiling(max(st_coordinates(NewData)[,2])),
      by = 1
    )
  )




# Plot 5: Planting Date
Fig9 <- A +
  geom_sf(data = NewData, aes(fill = PLtDate)) +
  scale_fill_distiller(palette = "Spectral", limits = range_PLtDate, 
                       breaks = c(range_PLtDate[1], mean(range_PLtDate), range_PLtDate[2]),  # min, mid, max
                       labels = function(x) sprintf("%.0f", x),  # <-- round to 0 decimal places
                       name = "Planting day") +
  theme_minimal() +
  labs(fill = "Planting day") +
  theme(axis.text = element_text(size = 20),
        axis.title.x = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        legend.text = element_text(size = 20),
        legend.title = element_text(size = 20),
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.key.width = unit(1, "cm")) +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    )
  )+
  xlab("Longitude") + ylab("Latitude") +
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
                                  ceiling(max(st_coordinates(NewData)[,1])), 
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
                                  ceiling(max(st_coordinates(NewData)[,2])), 
                                  by = 1)) 

# Plot 6: Avg Temp Flower to Open Boll
Fig10 <- A +
  geom_sf(data = NewData, aes(fill = AvgTempFtoOB)) +
  scale_fill_distiller(palette = "Spectral", limits = range_AvgTempFtoOB, 
                       breaks = c(range_AvgTempFtoOB[1], mean(range_AvgTempFtoOB), range_AvgTempFtoOB[2]),  # min, mid, max
                       labels = function(x) sprintf("%.1f", x),  # <-- round to 0 decimal places
                       name = "AvgTemp") +
  #scale_fill_gradientn(colors = c("green", "yellow","red"), name = "AvgTemp",limits = range_AvgTempFtoOB)+
  theme_minimal() +
  labs(fill = "AvgTemp") +
  theme(axis.text = element_text(size = 20),
        axis.title.x = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        legend.text = element_text(size = 20),
        legend.title = element_text(size = 20),
        legend.position = "bottom",
        legend.direction = "horizontal",
        legend.key.width = unit(1, "cm")) +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    )
  )+
  xlab("Longitude") + ylab("Latitude")  +
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
                                  ceiling(max(st_coordinates(NewData)[,1])), 
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
                                  ceiling(max(st_coordinates(NewData)[,2])), 
                                  by = 1)) 


#LWP
Fig11 <- A +
  geom_sf(data = NewData, aes(fill = MeanLWP)) +
  scale_fill_distiller(palette = "Spectral",
                       limits = range_LWP,
                       breaks = c(range_LWP[1], mean(range_LWP), range_LWP[2]),  # min, mid, max
                       labels = function(x) sprintf("%.1f", x),  # <-- round to 0 decimal places
                       name = "Mean LWP (MPa)") +
  theme_minimal() +
  labs(fill = "Mean LWP (MPa)") +
  theme(
    axis.text = element_text(size = 20),
    axis.title.x = element_text(size = 20),
    axis.title.y = element_text(size = 20),
    legend.text = element_text(size = 20),
    legend.title = element_text(size = 20),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.key.width = unit(1, "cm")
  ) +
  xlab("Longitude") +
  ylab("Latitude") +
  guides(
    fill = guide_colorbar(
      barwidth = 25,
      barheight = 1,
      title.position = "top",
      title.hjust = 0.5
    )
  ) +
  scale_x_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,1])), 
                                  ceiling(max(st_coordinates(NewData)[,1])), 
                                  by = 1)) +
  scale_y_continuous(breaks = seq(floor(min(st_coordinates(NewData)[,2])), 
                                  ceiling(max(st_coordinates(NewData)[,2])), 
                                  by = 1))


Fig5 
Fig6 
Fig7 
Fig8 
Fig9 
Fig10 
Fig11 

# Combine FQ plots
FQ <- ggarrange(Fig6,Fig7, Fig8, Fig5, Fig10, Fig11, nrow = 2, ncol = 3)
Temp_pday <- ggarrange(Fig5, Fig6, nrow = 1, ncol = 2)

# Save plots
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Planting_day_mid.jpeg", plot = Fig9, width = 10, height = 10)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/AvgTemp_mid.jpeg", plot = Fig10, width = 10, height = 10)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/FQ_mid.jpeg", plot = FQ, width = 30, height = 20, dpi = 500)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/FQ_mid.pdf", plot = FQ, width = 30, height = 20)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Temp_pday_mid.jpeg", plot = Temp_pday, width = 20, height = 15)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Micronaire_mid.jpeg", plot=Fig5, width = 10, height = 10)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Length_mid.jpeg", plot=Fig6, width = 10, height = 10)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Uniformity_mid.jpeg", plot=Fig7, width = 10, height = 10)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Strength_mid.jpeg", plot=Fig8, width = 10, height = 10)
ggsave("C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/Mean_LWP_mid.jpeg", plot = Fig11, width = 10, height = 10)




unique(data$county)
unique(NewData$county_name)




# ==============================================================================
# LIBRARIES
# ==============================================================================
library(readr)
library(dplyr)
library(tidyr)
library(openxlsx)

# ==============================================================================
# PHYSIOLOGICAL FUNCTIONS
# ==============================================================================

# Function to calculate running average temperature from a start day
calculate_running_avg <- function(data, start_day) {
  running_avg <- numeric(length(data$Tavg))
  running_sum <- 0
  count <- 0
  
  for (i in seq_along(data$Tavg)) {
    if (!is.na(data$yday[i]) && data$yday[i] >= start_day) {
      if (!is.na(data$Tavg[i])) {
        running_sum <- running_sum + data$Tavg[i]
        count <- count + 1
        running_avg[i] <- running_sum / count
      } else {
        running_avg[i] <- if(count > 0) running_sum / count else NA
      }
    } else {
      running_avg[i] <- NA
    }
  }
  return(running_avg)
}


# ==============================================================================
# FUNCTION TO COMPUTE DAILY LWP (UPDATED LOGIC)
# ==============================================================================

compute_daily_LWP <- function(planting_date, weather_data) {
  
  # Ensure planting date is integer (biologically realistic)
  planting_date <- round(planting_date)
  
  df <- weather_data %>%
    mutate(Tavg = (average_tmax + average_tmin) / 2) %>%
    arrange(yday)
  
  # ---------- STAGE 1: Time to First Square ----------
  df$AvgTemp_e <- calculate_running_avg(df, planting_date)
  df$TSQ <- 190.338 - 11.372 * df$AvgTemp_e + 0.194 * df$AvgTemp_e^2
  
  sq_indices <- which((df$yday - planting_date) >= df$TSQ)
  if (length(sq_indices) == 0) return(NULL)
  
  FFstartday <- min(df$yday[sq_indices], na.rm = TRUE)
  if (is.infinite(FFstartday)) return(NULL)
  
  
  # ---------- STAGE 2: Time to First Flower ----------
  df$AvgTemp_s <- calculate_running_avg(df, FFstartday)
  df$TFF <- 252.591 - 15.321 * df$AvgTemp_s + 0.2531 * df$AvgTemp_s^2
  
  ff_indices <- which((df$yday - FFstartday) >= df$TFF)
  if (length(ff_indices) == 0) return(NULL)
  
  FOBstartday <- min(df$yday[ff_indices], na.rm = TRUE)
  if (is.infinite(FOBstartday)) return(NULL)
  
  
  # ---------- STAGE 3: Time to First Open Boll ----------
  df$AvgTemp_b <- calculate_running_avg(df, FOBstartday)
  df$TFO <- 327.396 - 17.251 * df$AvgTemp_b + 0.255 * df$AvgTemp_b^2
  
  ob_indices <- which((df$yday - FOBstartday) >= df$TFO)
  if (length(ob_indices) == 0) return(NULL)
  
  OpenBollDay <- min(df$yday[ob_indices], na.rm = TRUE)
  if (is.infinite(OpenBollDay)) return(NULL)
  
  
  # ==============================================================================
  # UPDATED DAILY LWP CALCULATION (BOLL FILLING EQUATION ONLY)
  # LWP (MPa) = COHEN_SLOPE * CWSI + COHEN_INTERCEPT  (Cohen et al., 2015)
  # LWP_extrapolated flags days where Tmax exceeds calibration range (> 39°C).
  # ==============================================================================
  COHEN_SLOPE     <- -1.7727
  COHEN_INTERCEPT <- -1.2771
  CALIB_TEMP_MAX  <- 39.0

  df <- df %>%
    mutate(
      Daily_LWP        = COHEN_SLOPE * mean_cwsi + COHEN_INTERCEPT,
      LWP_extrapolated = average_tmax > CALIB_TEMP_MAX
    )
  
  
  # ==============================================================================
  # ADD STAGE LABELS (OPTIONAL BUT SCIENTIFICALLY USEFUL)
  # ==============================================================================
  
  df <- df %>%
    mutate(
      GrowthStage = case_when(
        yday < FFstartday                      ~ "Vegetative",
        yday >= FFstartday & yday < FOBstartday ~ "Squaring/Flowering",
        yday >= FOBstartday & yday < OpenBollDay ~ "Boll Filling",
        yday >= OpenBollDay                     ~ "Open Boll",
        TRUE                                    ~ NA_character_
      )
    )
  
  
  # ---------- CLEANUP ----------
  df <- df %>%
    select(-AvgTemp_e, -TSQ,
           -AvgTemp_s, -TFF,
           -AvgTemp_b, -TFO)
  
  return(df)
}


# ==============================================================================
# MAIN EXECUTION LOOP
# ==============================================================================

input_files_path <- "C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/temp_cwsi_joined_csv"
output_dir <- "C:/Users/jnm533/Desktop/Reddy cotton work/cwsi/CWSI-20260524T043047Z-3-001/Mid_LWP/mid_temp_lwp"

if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

files <- list.files(path = input_files_path,
                    full.names = TRUE,
                    pattern = "\\.csv$")

for (i in 1:nrow(final_results)) {
  
  curr_county <- toupper(final_results$County[i])
  curr_state  <- toupper(final_results$State[i])
  plant_date  <- final_results$PLtDate[i]
  
  match_pattern <- paste0("^", curr_state, "_", curr_county)
  
  file_match <- files[grepl(match_pattern,
                            basename(files),
                            ignore.case = TRUE)]
  
  if (length(file_match) == 0) {
    message("No file found for: ", curr_county, " in state: ", curr_state)
    next
  }
  
  weather_data <- read_csv(file_match[1],
                           show_col_types = FALSE)
  
  updated_df <- compute_daily_LWP(plant_date, weather_data)
  
  if (is.null(updated_df)) {
    message("Skipping ", curr_county,
            ": Could not calculate growth stages.")
    next
  }
  
  out_filename <- paste0(curr_state, "_",
                         curr_county,
                         "_with_LWP.csv")
  
  write_csv(updated_df,
            file.path(output_dir, out_filename))
  
  message("Successfully saved LWP data for: ", curr_county)
}

message("Batch processing complete. Files saved to: ", output_dir)